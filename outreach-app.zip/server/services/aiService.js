const axios = require('axios');

const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages';

const AI_PROMPT = (lead) => `
You are an outreach email writer for Devtronics, a full-stack SaaS development agency run by Zia Arsalan.

Devtronics provides:
- Custom web and mobile app development
- LoyalIdeas loyalty app (loyalideas.com) — a digital loyalty card system where customers earn and redeem points instantly to increase repeat orders for F&B businesses

Your task:
1. Visit the website: ${lead.website}
2. Look for any real issues (broken pages, outdated design, placeholder text, missing content, errors, slow loading, under-construction pages, typos, etc.)
3. Write a SHORT, personalized, professional outreach email to ${lead.name} at ${lead.business}

Email rules:
- Start with "Hi ${lead.name},"
- Briefly compliment something SPECIFIC and REAL about their business (from the website)
- If you found a website issue, mention it naturally as a helpful observation in ONE sentence
- If no clear issue is found, skip the website fix and focus purely on loyalty
- Pitch LoyalIdeas (loyalideas.com) in 1-2 sentences — keep it benefit-focused
- End with: "Interested in a quick 2-minute demo? Just reply "Demo" and I will send it over."
- Add a new line: "Reply STOP to unsubscribe."
- NO signature (the sender already has one)
- NO dashes (—) anywhere
- NO bullet points
- Keep it under 120 words total
- Tone: warm, professional, conversational

Also write a compelling subject line in this format:
"Boost [Business Name] Repeat Orders with Easy Loyalty Points" — add "(+ Website Fix)" only if there is a real issue to mention.

Return your response in this EXACT JSON format (no markdown, no extra text):
{
  "subject": "your subject line here",
  "body": "your email body here"
}
`;

const generateEmail = async (lead) => {
  const response = await axios.post(
    ANTHROPIC_API_URL,
    {
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      tools: [
        {
          type: 'web_search_20250305',
          name: 'web_search',
        },
      ],
      messages: [
        {
          role: 'user',
          content: AI_PROMPT(lead),
        },
      ],
    },
    {
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'anthropic-beta': 'web-search-2025-03-05',
      },
    }
  );

  // Extract text from response (may contain tool_use blocks)
  const content = response.data.content || [];
  const textBlock = content.filter((b) => b.type === 'text').map((b) => b.text).join('');

  // Parse JSON from the text
  const cleaned = textBlock.replace(/```json|```/g, '').trim();
  const parsed = JSON.parse(cleaned);

  return {
    subject: parsed.subject,
    body: parsed.body,
  };
};

module.exports = { generateEmail };

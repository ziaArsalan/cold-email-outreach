const { google } = require('googleapis');

const getSheetClient = () => {
  const auth = new google.auth.JWT({
    email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
  return google.sheets({ version: 'v4', auth });
};

// Fetch all rows where Status is empty (not yet emailed)
const fetchPendingLeads = async () => {
  const sheets = getSheetClient();
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: process.env.GOOGLE_SHEET_ID,
    range: 'Sheet1!A:F', // Email, Name, Business, Website, Status, Reference
  });

  const rows = response.data.values || [];
  if (rows.length <= 1) return []; // Only header

  const headers = rows[0]; // ['Email','Name','Business','Website','Status','Reference']
  const leads = [];

  rows.slice(1).forEach((row, index) => {
    const lead = {
      rowIndex: index + 2, // 1-indexed, +1 for header
      email: row[0] || '',
      name: row[1] || '',
      business: row[2] || '',
      website: row[3] || '',
      status: row[4] || '',
      reference: row[5] || '',
    };
    // Only include rows with an email and no status yet
    if (lead.email && (!lead.status || lead.status.trim() === '')) {
      leads.push(lead);
    }
  });

  return leads;
};

// Fetch all rows (for dashboard display)
const fetchAllLeads = async () => {
  const sheets = getSheetClient();
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: process.env.GOOGLE_SHEET_ID,
    range: 'Sheet1!A:F',
  });

  const rows = response.data.values || [];
  if (rows.length <= 1) return [];

  return rows.slice(1).map((row, index) => ({
    rowIndex: index + 2,
    email: row[0] || '',
    name: row[1] || '',
    business: row[2] || '',
    website: row[3] || '',
    status: row[4] || '',
    reference: row[5] || '',
  }));
};

// Update the Status column to "Emailed" for a given row
const updateLeadStatus = async (rowIndex, status = 'Emailed') => {
  const sheets = getSheetClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId: process.env.GOOGLE_SHEET_ID,
    range: `Sheet1!E${rowIndex}`, // Column E = Status
    valueInputOption: 'RAW',
    requestBody: { values: [[status]] },
  });
};

module.exports = { fetchPendingLeads, fetchAllLeads, updateLeadStatus };

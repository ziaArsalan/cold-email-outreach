const express = require('express');
const router = express.Router();
const { fetchPendingLeads, fetchAllLeads, updateLeadStatus } = require('../services/sheetsService');
const { generateEmail } = require('../services/aiService');
const { sendEmail, verifyConnection } = require('../services/emailService');

// Global job state
let jobState = {
  running: false,
  total: 0,
  processed: 0,
  success: 0,
  failed: 0,
  skipped: 0,
  logs: [],
  startedAt: null,
  finishedAt: null,
};

const addLog = (type, message) => {
  const entry = { type, message, time: new Date().toISOString() };
  jobState.logs.unshift(entry); // newest first
  if (jobState.logs.length > 200) jobState.logs.pop(); // cap at 200
  console.log(`[${type.toUpperCase()}] ${message}`);
};

// GET /api/leads — fetch all leads for dashboard
router.get('/leads', async (req, res) => {
  try {
    const leads = await fetchAllLeads();
    res.json({ success: true, leads });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/status — current job state
router.get('/status', (req, res) => {
  res.json(jobState);
});

// POST /api/preview — generate email preview for a single lead (no send)
router.post('/preview', async (req, res) => {
  const { lead } = req.body;
  if (!lead) return res.status(400).json({ success: false, error: 'Lead data required' });
  try {
    const email = await generateEmail(lead);
    res.json({ success: true, email });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/test-smtp — verify SMTP connection
router.post('/test-smtp', async (req, res) => {
  try {
    await verifyConnection();
    res.json({ success: true, message: 'SMTP connection verified' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/start — start the automation job
router.post('/start', async (req, res) => {
  if (jobState.running) {
    return res.status(400).json({ success: false, error: 'Job already running' });
  }

  const { batchSize = 10, delayMs = 3000 } = req.body;

  // Reset state
  jobState = {
    running: true,
    total: 0,
    processed: 0,
    success: 0,
    failed: 0,
    skipped: 0,
    logs: [],
    startedAt: new Date().toISOString(),
    finishedAt: null,
  };

  res.json({ success: true, message: 'Job started' });

  // Run job in background
  (async () => {
    try {
      addLog('info', 'Fetching pending leads from Google Sheets...');
      const leads = await fetchPendingLeads();
      jobState.total = leads.length;

      if (leads.length === 0) {
        addLog('info', 'No pending leads found. All done!');
        jobState.running = false;
        jobState.finishedAt = new Date().toISOString();
        return;
      }

      addLog('info', `Found ${leads.length} pending leads. Starting...`);

      // Process in batches
      const batch = leads.slice(0, batchSize);

      for (const lead of batch) {
        try {
          addLog('info', `Processing: ${lead.name} (${lead.email})`);

          // Step 1: Generate email via AI
          addLog('info', `Generating email for ${lead.name}...`);
          const { subject, body } = await generateEmail(lead);

          // Step 2: Send email
          addLog('info', `Sending email to ${lead.email}...`);
          await sendEmail({ to: lead.email, subject, body });

          // Step 3: Update sheet status
          await updateLeadStatus(lead.rowIndex, 'Emailed');

          jobState.success++;
          addLog('success', `Emailed ${lead.name} at ${lead.email} — Subject: "${subject}"`);
        } catch (err) {
          jobState.failed++;
          addLog('error', `Failed for ${lead.email}: ${err.message}`);
          // Mark as failed in sheet so we know
          try {
            await updateLeadStatus(lead.rowIndex, 'Failed');
          } catch (_) {}
        }

        jobState.processed++;

        // Delay between emails to avoid rate limits
        if (jobState.processed < batch.length) {
          await new Promise((r) => setTimeout(r, delayMs));
        }
      }

      addLog('info', `Job complete. Sent: ${jobState.success} | Failed: ${jobState.failed}`);
    } catch (err) {
      addLog('error', `Job crashed: ${err.message}`);
    } finally {
      jobState.running = false;
      jobState.finishedAt = new Date().toISOString();
    }
  })();
});

// POST /api/stop — stop the job (sets flag; graceful stop after current lead)
router.post('/stop', (req, res) => {
  jobState.running = false;
  addLog('info', 'Job manually stopped.');
  res.json({ success: true, message: 'Job stop requested' });
});

module.exports = router;
